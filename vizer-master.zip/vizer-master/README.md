# Vizer

A P5JS framework for running a simple music visualizer, intended as a creative coding I assignment.

Song details: // UPDATE THIS AS YOUR CHANGE YOUR SONG 
Title = Just Dropped In (To See What Condition My Condition Was In)
Artist = Kenny Rogers
