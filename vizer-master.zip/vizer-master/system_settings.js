// smoothing is applied to the audio file to smooth the signal
// expected values are from 0 (no smoothing) to 100 (lots of smoothing)
const smoothing = 25;
// debugFastRefresh can be set to true to go straight to the song
const debugFastRefresh = true;